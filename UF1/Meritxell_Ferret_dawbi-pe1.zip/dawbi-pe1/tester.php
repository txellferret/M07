<?php
namespace proven\files;
require_once "php-fn/file.fn.php";

echo "File: users.txt";
echo "<br>";
$file = "files/users.txt";
echo "<br>";

echo "1. <br>";
echo "Reads a file: ";
echo "<br>";
$lines = readAllLines($file); 
print_r(($lines));
echo "<br>";
echo "<br>";

///////
echo "2. <br>";
echo "Writes lines";
echo "<br>";
echo "Lines to write: ";
$linesToAdd = array ("7;user7;pass7;staff;name7;surname7", "8;user;pass8;admin;name8;surname8");
print_r($linesToAdd);
echo "<br>";
echo "number of lines written: ";
echo (writeAllLines($file, $linesToAdd));
echo "<br>";
echo "<br>";

//////
echo "3. <br>";
echo "lines of role admin";
echo "<br>";


$searchLines = readLinesWhereFieldIndex($file, 3, "admin");
print_r($searchLines);
echo "<br>";
echo "<br>";

///////
echo "4. <br>";
echo "Append lines";
$linesWritten = appendLine($file,"9;user;pass9;admin;name9;surname9" );

echo "lines written :".$linesWritten;




?>
