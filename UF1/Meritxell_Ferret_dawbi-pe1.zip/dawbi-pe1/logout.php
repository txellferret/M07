<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>DAWBI-M07 PE1</title>
        <!--css files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    </head>
    <body>
        <?php include_once "mainmenu.php"; ?>
        <h2>Logout page</h2>
<?php
/*
 * logout page.
 * shows previus rating made by the user (read from a cookie),
 * if the cookie does not exist, shows the message 'no previous rating'.
 * asks the user to rate his/her experience with the application
 * from 1 to 5 and stores that value in a cookie,
 * and, finally, performs session data cleanup, removes session cookie 
 * and goes to index.php.
 * Restrictions: this script is only available to users with started session,
 * that is, users who are logged in the application.
 */
session_start();
if (isset($_SESSION["userRole"])) {  //user valid
    if (isset($_COOKIE['rate'])) {

        $ratePrevious = filter_input(INPUT_COOKIE,'rate');
        echo "your previous rate: ".$ratePrevious;
        // destroy everything in this session
         unset($_SESSION);
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"],$params["httponly"]);
        }
        session_destroy();
        echo "<p>Logout done.</p>";


    } else {
        echo "no previous rating"; ?>
        <form id = "myForm" name="rate-form" method="get" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>">
            <div class="form-group row">
                                    <label for="rate" class="col-sm-2 col-form-label">Rate yout experience: </label>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="rate">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>
                                </div>

                            <div class="col-10">
                                    <button type="submit" class="btn btn-success" name ="send">Send</button>
                            </div>

        </form>

        <?php
        if (!is_null(filter_input(INPUT_GET, "send"))) {
    
            $rate = trim((string)filter_input(INPUT_GET, 'rate'));
            setcookie('rate',$rate, time() + (60 * 10)); //10 min

            unset($_SESSION);
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"],$params["httponly"]);
            }
            session_destroy();
            echo "<p>Logout done.</p>";
        
        }
    }
    

    
}else {  //user not logged yet.
    echo "<p>Not logged!</p>";
    header("Location:index.php");  //redirect to application page        
}



?>



        
        <?php include_once "footer.php"; ?>
    </body>
</html>

