 
<?php $__env->startSection('topmenu'); ?>
    ##parent-placeholder-d9e759e588c75d6d1fef9b428db7be6e57ed4036##
    <a href="http://www.google.es">Google</a>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<h2>Welcome to Item manager applicacion</h2>
<p>An applicacion made with Laravel framework</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/txellfe/Desktop/insti GIT/M07/M07/UF4/items/resources/views/welcome.blade.php ENDPATH**/ ?>