
@extends('layout')
 
@section('content')
<h2>Item page</h2>
<ul>
    <li><a href="/items/list">List Items</a></li>    
</ul>
@endsection