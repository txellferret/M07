
<nav class="navbar navbar-default navbar-expand-sm navbar-light bg-light">
<div class="container-fluid">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="/home">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/items/list">Items</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/notes/list">Notes</a>
        </li>
    </ul>
</div>
</nav>
