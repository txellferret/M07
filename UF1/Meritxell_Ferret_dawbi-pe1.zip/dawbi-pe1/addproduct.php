<?php
/*
 * show a form to input data for a new product,
 * and sends to itself to validate and perfom persistence in file.
 * Restrictions: this script is only available to users with role 'admin'.
 */

namespace proven\files;
include_once "php-fn/file.fn.php";

$filePathProd = "files/products.txt";

session_start();
if($_SESSION['userRole'] != "admin" ) {
    header("Location:login.php");
}

$path = "files/";
$inputFileProd = "products.txt";
 


if (!is_null(filter_input(INPUT_GET, "addProd"))) {

    //variables
    $id = filter_input(INPUT_GET, 'id',  FILTER_VALIDATE_INT);
    $description = filter_input(INPUT_GET, 'desc', FILTER_SANITIZE_STRING);
    $price = filter_input(INPUT_GET, 'price', FILTER_VALIDATE_FLOAT);
    $stock = filter_input(INPUT_GET, 'stock', FILTER_VALIDATE_INT);

    //validate 
    if ($id != false && $price != false && $stock != false ) {
        //check if id is already used
        if (checkUniqueId($id,$path.$inputFileProd)){
            $newProd = array ($id, $description, $price, $stock);
            $lineProd = implode(";", $newProd);

            if (file_put_contents($filePathProd, $lineProd.PHP_EOL, FILE_APPEND | LOCK_EX)) {
                $message = "Product successfully added";
                $id = "";
                $description = "";
                $price = "";
                $stock = "";

            }else {
                $message = "Product UNsuccessfully added";
            }
        }else {
            $message = "Product id already used";
        }
        
    } else{
        $message = "Wrong value introduced for id, price or stock";
    }
}
/**
 * Checks if a given id already exits in a data file
 * @param id to check
 * @param filepath to search
 * @return true if it is unique, false otherwise
 */
function checkUniqueId ($id, $filePath) : bool {
    $unique = true;
    $handle = fopen($filePath,'r');
    //posem 0 per omitir caracters de fi de linea
    while (($row = fgetcsv($handle,0,";")) !== FALSE) {
        if ($row[0] === $id) {
            $unique = false;
        break;
        }

    }
    
    fclose($handle);
    return $unique;
}

?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <!--css files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

        <title>DAWBI-M07 PE1</title>
    </head>
    <body>
        <?php include_once "mainmenu.php"; ?>
        <h2>Form to add a new product</h2>
        <div class="container ">
        <div class="card mt-5 mb-5" style="width: 100%;">
            <div class="card-header text-center"><h4>Add new product</h4></div>
                <div class="card-body">
                    <form id = "myForm" name="menu-form" method="get" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>">
                        <div class="form-group row">
                            <label for="id" class="col-sm-2 col-form-label">Id: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="id"   value = "<?php echo $id; ?> " required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="desc" class="col-sm-2 col-form-label">Description: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="desc"  value = "<?php echo $description; ?> "required></input>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="price" class="col-sm-2 col-form-label">Price: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="price"  value = "<?php echo $price; ?> " required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="stock" class="col-sm-2 col-form-label">Stock: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="stock"  value = "<?php echo $stock; ?> "  required>
                            </div>
                        </div>

                        <div class="form-group row justify-content-between">
                            <div class="col-10">
                                <button type="submit" class="btn btn-success" name ="addProd">Add Product</button>
                            </div>
                            <div class="col-1 mr-3">
                                <button type="button" class="btn btn-secondary"><a href ="index.php" style="color: white; text-decoration: none">Cancel</a></button>  
                            </div>
                        </div>
                        <p><?php echo $message?></p>
                    </form>
                </div>
        </div>
    </div>
        <?php include_once "footer.php"; ?>
    </body>
</html>