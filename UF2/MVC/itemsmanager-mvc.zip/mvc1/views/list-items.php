<!DOCTYPE html> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>MVC. List all items</title>
    <link type="text/css" rel="stylesheet" href="css/styles.css" >
</head>
<body>
<table>
    <h2>List all items</h2>
    <tr>
        <th>ID</th>
        <th>Item</th>
    </tr>
    <?php
    //display list of items in a table.
    $itemList = $params['itemList'];
    // $params contains variables passed in from the controller.
    foreach ($itemList as $item) {
        echo <<<EOT
        <tr>
            <td>{$item->getId()}</td>
            <td>{$item->getItem()}</td>
        </tr>               
EOT;
    }
    ?>
</table>
</body>
</html>