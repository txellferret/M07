<?php
require_once 'Item.php';
require_once 'ItemAdo.php';
/**
 * Service class to provide queries from item data source.
 */
class ItemsModel {
    
    private $dataSource;
 
    public function __construct() {
        //get an instance of ADO class.
        $this->dataSource = ItemAdo::getInstance();
    }

    /**
     * finds all items.
     * @return list of items
     */
    public function findAll() {
        $items = $this->dataSource->getData();
        return $items;
    }

}
?>