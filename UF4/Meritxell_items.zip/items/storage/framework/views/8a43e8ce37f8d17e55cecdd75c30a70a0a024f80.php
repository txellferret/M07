 
<?php $__env->startSection('content'); ?>
<h3>Add new item</h3>
<?php if(isset($data['msg'])): ?>
    <p><?php echo e($data['msg']); ?></p>
<?php endif; ?>
<form action="/additem" method="post">
<?php echo e(csrf_field()); ?>

    <div>
        <label for="title">Title:</label>
        <input type="text" name="title" value="" required/>
    </div>
    <div>
        <label for="content">Content:</label>
        <input type="text" name="content" value="" required/>
    </div>
    <button class="btn btn-success" type="submit">Add</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/txellfe/Desktop/insti GIT/M07/M07/UF4/items/resources/views/item/addform.blade.php ENDPATH**/ ?>