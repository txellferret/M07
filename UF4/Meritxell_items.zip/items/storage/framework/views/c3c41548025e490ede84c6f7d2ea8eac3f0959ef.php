
<nav class="navbar navbar-default navbar-expand-sm navbar-light bg-light">
<div class="container-fluid">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="/home">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/items/list">Items</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/notes/list">Notes</a>
        </li>
    </ul>
</div>
</nav>
<?php /**PATH /home/txellfe/Desktop/insti GIT/M07/M07/UF4/items/resources/views/menubar.blade.php ENDPATH**/ ?>