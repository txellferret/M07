<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/items.css')); ?>" />

    
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <?php $__env->startSection('topmenu'); ?>
    <?php echo $__env->make('menubar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php $__env->startSection('footer'); ?>
    <footer>Application by ProvenSoft.</footer> 
    <?php echo $__env->yieldSection(); ?>

</body>
</html><?php /**PATH /home/txellfe/Desktop/insti GIT/M07/M07/UF4/items/resources/views/layout.blade.php ENDPATH**/ ?>