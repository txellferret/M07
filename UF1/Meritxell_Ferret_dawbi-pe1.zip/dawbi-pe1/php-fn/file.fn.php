<?php

/**
 * utility functions to handle text files.
 */

namespace proven\files {

    /**
     * reads a file into an array of string (one line each).
     * @param string $filepath path to file read from.
     * @return array the array of string elements with that have been read.
     */
    function readAllLines(string $filepath): array {
        $data = array();
        $data = file($filepath);
        return $data;
    }

    /**
     * writes an array of string to a file.
     * @param string $filepath path to file to write in.
     * @param array $data the data to be written.
     * @return int the number of lines actually written to file.
     */
    function writeAllLines(string $filepath, array $data): int {
        $linesWritten = 0;
        $h = fopen($filepath, "w");
        if ($h !==false ) {
            // Guardar los cambios en el archivo:
            for ($i=0; $i < count($data); $i++) { 
                trim($data[$i]);
                fwrite($h, $data[$i].PHP_EOL);
                $linesWritten += 1;
            }
           
        }
        fclose($h);
        
        return $linesWritten;
    }

    /**
     * reads and gets all lines in file with given value in the field at position given by index.
     * @param string $filepath path to file read from.
     * @param int $fieldIndex index of field to search. (the column)
     * @param string $fieldValue value to search.
     * @return array the array of lines according to given criterion.
     */
    
    function readLinesWhereFieldIndex(string $filepath, int $fieldIndex, string $fieldValue){
        $result = array();
        $lines = file($filepath); //each elem is a line
            for ($i=0; $i < count($lines); $i++) { 
                $line = explode(";", $lines[$i]); //line is an array of elements of the line
                if ($line[$fieldIndex] == $fieldValue) {
                    array_push($result, $lines[$i]);
                }
            }

        
        return $result;
    }


    /**
     * appends a line to file.
     * @param string $filepath path to file to write in.
     * @param string $data the line to bo written to file.
     * @return int the number of lines actually written.
     */
    function appendLine(string $filepath, string $data): int {
        $linesWritten = 0;
        if(file_put_contents($filepath, $data.PHP_EOL, FILE_APPEND | LOCK_EX)) {
            $linesWritten += 1;
        }
        return $linesWritten;
    }

}

