<?php
/**
 * context configuration.
 */
class Context {
    
    protected $properties;
    protected static $instance;
 
    protected function __construct() {
        $this->properties = array();
    }

    public static function getInstance() {
        if (!isset(self::$instance)) {
            self::$instance = new Context();
        }
        return self::$instance;
    }    
    
    public function set($name, $value) {
        if(!isset($this->properties[$name])) {
            $this->properties[$name] = $value;
        }
    }
 
    public function get($name) {
        if(isset($this->properties[$name])) {
            return $this->properties[$name];
        }
    }
 
}
?>