 
<?php $__env->startSection('content'); ?>
<h3>List items</h3>
<?php if(isset($data['msg'])): ?>
    <div><p class="alert alert-warning"><?php echo e($data['msg']); ?></p></div>
<?php endif; ?>
<?php if(empty($data['items'])): ?>
    <p>There are no items!</p>
<?php else: ?>
<table class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Title</th>
            <th>Content</th>
            <th>Notes</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="/items/<?php echo e($item->id); ?>"><?php echo e($item->id); ?></a></td>
            <td><?php echo e($item->title); ?></td>
            <td><?php echo e($item->content); ?></td>
            <td>
                <label for="notes">Notes:</label>
                <ul>
                    <?php $__currentLoopData = $item->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($note->content); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </td>
            <td>
                <form action="/items/<?php echo e($item->id); ?>/delete" method="post">
                <?php echo e(csrf_field()); ?>

                    <button class="btn btn-danger" type="submit" onclick="return confirmDialog()">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <button onclick="location.href = '/itemform';" class="btn btn-primary" >Add new</button>
</table>

<?php endif; ?>
 
<?php $__env->stopSection(); ?>

<script>
function confirmDialog() {
    return window.confirm("Are you sure?");
}

</script>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/txellfe/Desktop/insti GIT/M07/M07/UF4/items/resources/views/item/list.blade.php ENDPATH**/ ?>