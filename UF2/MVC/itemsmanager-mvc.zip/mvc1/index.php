<?php
    require 'controllers/MainController.php';
    (new MainController())->processRequest();
?>