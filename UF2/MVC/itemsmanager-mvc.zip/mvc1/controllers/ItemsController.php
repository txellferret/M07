<?php
require_once 'libs/ViewLoader.php';

class ItemsController {
    /**
     * @var ViewLoader
     */
    private $view;
    
    function __construct() {
        //instantiate the view loader.
        $this->view = new ViewLoader();
    }
 
    /**
     * lists all items.
     */
    public function listAll() {
        //include model.
        require 'model/ItemsModel.php';
        //instantiate the model.
        $items = new ItemsModel();
        //get all items.
        $itemList = $items->findAll();
        //pass data to template.
        $data['itemList'] = $itemList;
        //show the template with the given data.
        $this->view->show("list-items.php", $data);
    }
 
}
?>