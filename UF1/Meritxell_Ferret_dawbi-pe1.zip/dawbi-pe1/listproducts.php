<?php
/*
 * shows data of all products in a table.
 * Restrictions: this script is only available to users with role 'admin' or 'registered'.
 */
namespace proven\files;
include_once "php-fn/file.fn.php";

session_start();
if($_SESSION['userRole'] != "admin" && $_SESSION['userRole'] != "staff" ) {
    header("Location:login.php");
}

$path = "files/";
$inputFileMenu = "products.txt";

//array of each product with its properties
$products = file($path.$inputFileMenu);



/**
 * Lists all elements
 * @param array of lines to list
 */
function listInput(array $lines) {
    for ($i=0; $i < count($lines); $i++) { 
        $line = explode(";", $lines[$i]);
        echo "<tr>";
        
        echo "<td>$line[0]</td>";
        for ($j=1; $j < count($line); $j++) { 
            echo "<td>".$line[$j]."</td>";
        }
        echo "</tr>";   
    } 
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
          <!--css files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

        <title>DAWBI-M07 PE1</title>
    </head>
    <body>
        <?php include_once "mainmenu.php"; ?>
        <h2>List of all products</h2>
        <div class="container ">
        <div class="card mt-5 mb-5" style="width: 100%;">
            <div class="card-header text-center"><h4>Prodcuts lists</h4></div>
            <table class="table text-center">
                <thead class="thead-light"><tr><th>Id</th><th>Desc</th><th>Price</th><th>Stock</th></tr></thead>
                <tbody>
                    <?php listInput($products); ?>
               <tbody>
            </table>
            
            
        </div>
        <br>
        <br>
        <br>
    </div>
        <?php include_once "footer.php"; ?>
    </body>
</html>