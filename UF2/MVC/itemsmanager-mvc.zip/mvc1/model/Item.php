<?php

/**
 * Item class definition.
 */
class Item {
    private $id;
    private $item;

    public function __construct($id, $item) {
        $this->id = $id;
        $this->item = $item;
    }
    
    public function getId() {
        return $this->id;
    }
    
    public function setId($id) {
        $this->id = $id;
    }
    
    public function getItem() {
        return $this->item;
    }    
    
    public function setItem($item) {
        $this->item = $item;
    }
    
    public function __toString() {
        return "Item: {id=$this->id; item=$this->item}";
    }
    
}
?>