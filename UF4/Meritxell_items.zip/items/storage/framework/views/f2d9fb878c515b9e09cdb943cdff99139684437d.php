 
<?php $__env->startSection('content'); ?>
<h3>List notes</h3>
<?php if(isset($data['msg'])): ?>
    <div><p class="alert alert-warning"><?php echo e($data['msg']); ?></p></div>
<?php endif; ?>
<?php if(empty($data['notes'])): ?>
    <p>There are no notes!</p>
<?php else: ?>
<table class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Item id</th>
            <th>Content</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data['notes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($note->id); ?></td>
            <td><?php echo e($note->item_id); ?></td>

            <td><?php echo e($note->content); ?></td>
            <td><button onclick="location.href = '/notes/<?php echo e($note->id); ?>';" class="btn btn-primary" >Edit</button></td>
            <td>
                <form action="/notes/<?php echo e($note->id); ?>/delete" method="post">
                <?php echo e(csrf_field()); ?>

                    <button class="btn btn-danger" type="submit" onclick="return confirmDialog()">Delete</button>
                </form>
            </td>
            
            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php endif; ?>
 
<?php $__env->stopSection(); ?>

<script>
function confirmDialog() {
    return window.confirm("Are you sure?");
}

</script>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/txellfe/Desktop/insti GIT/M07/M07/UF4/items/resources/views/note/list.blade.php ENDPATH**/ ?>