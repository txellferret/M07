<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--css files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/main.css">

    <title>Document</title>
</head>
<body>
    <footer class="page-footer font-small blue bg-light">
        <div class="footer-copyright text-center py-3">© 2020 Copyright:
        <a href="#"> txellfe</a>
        </div>
    </footer>

</body>
</html>