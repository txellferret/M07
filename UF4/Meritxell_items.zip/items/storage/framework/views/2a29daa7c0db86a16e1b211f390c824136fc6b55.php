 
<?php $__env->startSection('content'); ?>
<h2>Item page</h2>
<ul>
    <li><a href="/items/list">List Items</a></li>    
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/txellfe/Desktop/insti GIT/M07/M07/UF4/items/resources/views/item/index.blade.php ENDPATH**/ ?>