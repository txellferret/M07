<?php
namespace proven\files;
require_once "php-fn/file.fn.php";

/*
 * login page.
 * shows a form to input username and password and sends to itself to validate
 * credentals,
 * If credentials are valid, navigate to index.php, otherwise show error and
 * remain is this page.
 * Restrictions: this script is only available to users without active session.
 */

session_start();
if (isset($_SESSION['userRole'])) {
    echo "User already logged in";
    header("Location:index.php");  //redirect to application page

}

$path = "files/users.txt";

$userWrong = "";
$message = "";

if (!is_null(filter_input(INPUT_POST,'submit'))) {
    $userInput = filter_input(INPUT_POST, "userName");
    $passwordInput = filter_input(INPUT_POST, "password");

    //validations.
    if ((trim($userInput) === "") || (trim($passwordInput) === "")) {
        $message = "<li>User and password required.</li>";
    }
    else {
        //assess file existance
        if (!file_exists($path)) {
            echo "File not found";
            header("Location:index.php");  //redirect to application page

        }   
    
        //read file into an array of lines
        $lines = readAllLines($path);
    
        for ($i=0; $i < count($lines); $i++) { 
            $userPass = explode(";", $lines[$i]);
            if (strcmp($userPass[1], $userInput) === 0) {
                if (strcmp(trim($userPass[2]), $passwordInput) === 0) {
                    $_SESSION["loggedin"] = true;
                    $_SESSION["userRole"] = $userPass[3];
                    $_SESSION["userName"] = $userPass[1]; 
                    $message =  "<p>Successfully loged in!.</p>";

                } else $message = "<b>Invalid password</b>";
    
            break;
            } else { //bad login: redirect to login page again.
                $userWrong = $userInput;
                $message = "<b>Invalid user</b>";
                
            } 
        }
    }   
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <!--css files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

        <title>DAWBI-M07 PE1</title>
    </head>
    <body>
        <?php include_once "mainmenu.php"; ?>
        <h2>Login page</h2>
        <div class="container ">
        <div class="card mt-5" style="width: 100%;">
            <div class="card-body">
                <form name="login-form" method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>">
                    <fieldset>
                        <legend>Log in!</legend>
                        <label for="userName">Username:</label>
                        <input type="text" name="userName" value ="<?php echo $userWrong?>"></input>
                        <label for="password">Password:</label>
                        <input type="password" name="password">
                        <br>
                        <br>
                        <button class="btn btn-secondary" type="submit" name="submit">Submit</button>
                        <button class="btn btn-secondary"><a href="index.php">Go home</a></button>
                        <p><?php echo $message?> </p>
                    </fieldset>
                </form>
            </div>
        </div>
        <?php include_once "footer.php"; ?>
    </body>
</html>