
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--css files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Italian Restaurant</title>
</head>
<body background="../images/mesas.jpg">
<?php include_once "topMenu.php"; ?>
    <div class="container ">
        <br>
        <br>
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2>Welcome to our Restaurant!</h2>
                <img  class ="img-fluid" src="../images/logo.jpg" alt="restaurant-logo">
            </div>
            <div class="col-md-6" >
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptates non asperiores ipsa et modi harum odio quasi totam voluptate deserunt maxime, fugiat vel magnam dolorum? Praesentium voluptates, possimus sunt deserunt quisquam id! Placeat cumque nesciunt modi quas magnam numquam voluptatum quam minus, impedit dolores quibusdam sapiente eius quod, culpa soluta voluptates provident assumenda illum mollitia adipisci voluptate laboriosam consequuntur ratione sequi! Dolorem beatae, sapiente accusantium veritatis porro ullam quae voluptas minus, fugit officiis, odit inventore doloremque! Earum quae eos fugiat qui quisquam doloribus enim quas vel ad eligendi atque, placeat a saepe dolore ex? Maxime, ullam? Et, aut laborum! Odit.</p>
            </div>
        </div>
    </div>
</body>
    <?php include "footer.php";?>

</html>
