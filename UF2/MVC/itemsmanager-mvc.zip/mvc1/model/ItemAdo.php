<?php
/**
 * Item persistence class.
 */
class ItemAdo {
    private static $instance = null;
    private $data;
 
    private function __construct() {
        //create test data.
        $this->data = array();
        $this->data[] = new Item("1", "item1");
        $this->data[] = new Item("2", "item2");
        $this->data[] = new Item("3", "item4"); 
    }
 
    public static function getInstance() {
        if( self::$instance == null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getData() {
        return $this->data;
    }
}
?>