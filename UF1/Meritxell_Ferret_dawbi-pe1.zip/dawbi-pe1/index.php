<?php
session_start();


?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>DAWBI-M07 PE1</title>
        <!--css files -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    </head>
    <body>
        <?php include_once "mainmenu.php"; ?>
        <h2>Home page</h2>
        <?php
        session_start();

        if (isset($_SESSION['userRole'])) {
            $role = $_SESSION["userRole"];
            $username = $_SESSION["userName"];

            echo "Welcome ".$username;
            echo "<br>";
        }
        ?>
        <img src="images/shopping.jpg" alt="Shop photograph" height="400" width="600">
        <?php include_once "footer.php"; ?>
    </body>
</html>
